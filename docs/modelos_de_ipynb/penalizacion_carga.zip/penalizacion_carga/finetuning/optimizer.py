"""
Optimizador de fine-tuning.

Orquesta la búsqueda de parámetros óptimos usando la función de pérdida
distribucional, con soporte para múltiples algoritmos (DE, random search,
L-BFGS-B, Optuna).
"""

from __future__ import annotations

import time
import math
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from penalizacion_carga.model import PenalizacionCargaHistoricaModel, ModelParams
from penalizacion_carga.finetuning.config import (
    FineTuningConfig,
    LossConfig,
    OptimizerConfig,
    ParamBounds,
)
from penalizacion_carga.finetuning.loss import compute_distributional_loss
from penalizacion_carga.finetuning.scenarios import generate_evaluation_scenarios


# ============================================================================
# Interfaz principal
# ============================================================================

def finetune(
    model: PenalizacionCargaHistoricaModel,
    config: Optional[FineTuningConfig] = None,
    *,
    verbose: bool = True,
    progress_callback: Optional[Callable[[int, int, float], None]] = None,
) -> Dict[str, Any]:
    """
    Ejecuta fine-tuning global sobre el modelo.

    Args:
        model: modelo entrenado (fit)
        config: configuración completa. Si es None, usa FineTuningConfig.default()
        verbose: mostrar progreso
        progress_callback: función(iteracion, total, loss) para barras de progreso

    Returns:
        dict con:
            - model: modelo optimizado (nueva instancia)
            - best_params: dict con parámetros óptimos
            - best_loss: pérdida final
            - loss_components: desglose de componentes de pérdida
            - history: lista de (iteración, loss) durante la optimización
            - evaluation: DataFrame con predicciones finales
            - metrics: dict con métricas de diagnóstico
    """
    if config is None:
        config = FineTuningConfig.default()

    # ── Guardar params iniciales para regularización ──
    initial_params = model.params.to_dict()

    # ── Preparar bounds planos para el optimizador ──
    flat_bounds, param_names, log_mask = _flatten_bounds(
        config.param_bounds_semanal, config.param_bounds_bloques
    )

    # ── Codificar params actuales como punto de partida ──
    x0 = _encode_params(model.params, param_names, log_mask)

    if not flat_bounds:
        return {
            "model": model,
            "best_params": {},
            "best_loss": float("inf"),
            "loss_components": {},
            "history": [],
            "evaluation": pd.DataFrame(),
            "metrics": {},
        }

    # ── Función objetivo (envuelta con tracker de progreso) ──
    # Estimar total de evaluaciones según algoritmo
    algo = config.optimizer.algorithm
    if algo == "differential_evolution":
        total_evals = config.optimizer.max_iterations * config.optimizer.population_size
        label = f"[DE] pop={config.optimizer.population_size}"
    elif algo == "random_search":
        total_evals = config.optimizer.random_samples + (1 if x0 is not None else 0)
        label = "[RandomSearch]"
    elif algo in ("L-BFGS-B", "lbfgsb"):
        total_evals = config.optimizer.lbfgsb_maxiter
        label = "[L-BFGS-B]"
    elif algo == "optuna":
        total_evals = config.optimizer.optuna_n_trials
        label = "[Optuna]"
    else:
        total_evals = 1
        label = ""

    tracker = _ProgressTracker(
        total_evals=total_evals,
        label=label,
        verbose=verbose,
    )

    def _raw_objective(x: np.ndarray) -> float:
        params_dict = _decode_params(x, param_names, log_mask)
        test_model = _apply_params(model, params_dict)
        scenarios = generate_evaluation_scenarios(
            test_model,
            n_scenarios_per_eco=config.n_evaluation_scenarios_per_eco,
            seed=config.evaluation_seed,
            min_trimestres=config.min_trimestres_eco,
            max_ecos=config.n_evaluation_ecos_sample,
        )
        if len(scenarios) == 0:
            return 1e6

        loss_dict = compute_distributional_loss(
            test_model, scenarios, config.loss, initial_params
        )
        return loss_dict["loss_total"]

    def objective(x: np.ndarray) -> float:
        loss = float(_raw_objective(x))
        tracker.register_eval(loss)
        return loss

    # ── Ejecutar optimización según algoritmo ──
    history: List[Tuple[int, float]] = []
    start_time = time.time()

    if algo == "differential_evolution":
        result = _optimize_de(objective, flat_bounds, config.optimizer, tracker, history)
    elif algo == "random_search":
        result = _optimize_random(objective, flat_bounds, config.optimizer, tracker, history, x0=x0)
    elif algo in ("L-BFGS-B", "lbfgsb"):
        result = _optimize_lbfgsb(objective, flat_bounds, config.optimizer, tracker, history)
    elif algo == "optuna":
        result = _optimize_optuna(objective, flat_bounds, config.optimizer, tracker, history)
    else:
        raise ValueError(f"Algoritmo no reconocido: {algo}")

    tracker.finish()
    elapsed = time.time() - start_time

    # ── Construir modelo final ──
    best_x = result["x"]
    best_params = _decode_params(best_x, param_names, log_mask)
    best_model = _apply_params(model, best_params)

    # ── Evaluación final ──
    final_scenarios = generate_evaluation_scenarios(
        best_model,
        n_scenarios_per_eco=max(5, config.n_evaluation_scenarios_per_eco),
        seed=config.evaluation_seed,
        min_trimestres=config.min_trimestres_eco,
        max_ecos=config.n_evaluation_ecos_sample,
    )

    final_loss_dict = compute_distributional_loss(
        best_model, final_scenarios, config.loss, initial_params
    )

    # ── Métricas de diagnóstico ──
    metrics = _compute_diagnostics(best_model, final_scenarios)

    if verbose:
        _print_summary(best_params, final_loss_dict, metrics, algo, elapsed)

    return {
        "model": best_model,
        "best_params": best_params,
        "best_loss": final_loss_dict["loss_total"],
        "loss_components": final_loss_dict,
        "history": history,
        "evaluation": final_scenarios,
        "metrics": metrics,
    }


# ============================================================================
# Codificación/decodificación de parámetros
# ============================================================================

def _flatten_bounds(
    bounds_semanal: ParamBounds,
    bounds_bloques: ParamBounds,
) -> Tuple[List[Tuple[float, float]], List[str], List[bool]]:
    """Convierte bounds semánticos en vectores planos para el optimizador."""
    flat: List[Tuple[float, float]] = []
    names: List[str] = []
    log_mask: List[bool] = []

    for bounds in [bounds_semanal, bounds_bloques]:
        for param_name, (lo, hi, log_scale) in bounds.bounds.items():
            if param_name == "lambda_ueas":
                # Expandir tuple en 5 parámetros individuales
                for i in range(5):
                    flat.append((lo, hi))
                    names.append(f"lambda_ueas_{i}")
                    log_mask.append(log_scale)
            else:
                flat.append((lo, hi))
                names.append(param_name)
                log_mask.append(log_scale)

    return flat, names, log_mask


def _encode_params(
    params: ModelParams, param_names: List[str], log_mask: List[bool]
) -> np.ndarray:
    """Codifica ModelParams → vector x para el optimizador."""
    x = np.zeros(len(param_names))
    d = params.to_dict()

    for i, (name, use_log) in enumerate(zip(param_names, log_mask)):
        if name.startswith("lambda_ueas_"):
            idx = int(name.split("_")[-1])
            val = d.get("lambda_ueas", [1.0] * 5)[idx]
        else:
            val = d.get(name, 1.0)

        if use_log:
            x[i] = math.log(max(val, 1e-9))
        else:
            x[i] = float(val)

    return x


def _decode_params(
    x: np.ndarray, param_names: List[str], log_mask: List[bool]
) -> Dict[str, Any]:
    """Decodifica vector x → dict de parámetros."""
    params_dict: Dict[str, Any] = {"lambda_ueas": [1.0] * 5}
    lambda_ueas = list(params_dict["lambda_ueas"])

    for i, (name, use_log) in enumerate(zip(param_names, log_mask)):
        val = math.exp(x[i]) if use_log else float(x[i])

        if name.startswith("lambda_ueas_"):
            idx = int(name.split("_")[-1])
            lambda_ueas[idx] = val
        else:
            params_dict[name] = val

    params_dict["lambda_ueas"] = tuple(lambda_ueas)
    return params_dict


def _apply_params(
    model: PenalizacionCargaHistoricaModel,
    params_dict: Dict[str, Any],
) -> PenalizacionCargaHistoricaModel:
    """
    Crea una copia ligera del modelo con nuevos parámetros.

    Usa clone_light() para compartir perfiles/registros por referencia
    y solo clonar ModelParams. Esto evita serializar 1500+ ecos por iteración.
    """
    new_model = model.clone_light()
    for key, value in params_dict.items():
        if hasattr(new_model.params, key):
            setattr(new_model.params, key, value)
    return new_model


# ============================================================================
# Barra de progreso con ETA (in-place, limpia la línea en cada update)
# ============================================================================

import sys


def _format_time(seconds: float) -> str:
    """Formatea segundos a H:MM:SS o M:SS según convenga."""
    if seconds < 0:
        return "--:--"
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def _render_progress(
    iteration: int,
    total: int,
    best_loss: float,
    current_loss: float,
    elapsed: float,
    label: str = "",
) -> str:
    """
    Renderiza una barra de progreso con ETA en una sola línea.
    Devuelve el string listo para imprimir con \\r.
    """
    frac = min(iteration / max(total, 1), 1.0)
    bar_width = 30
    filled = int(bar_width * frac)
    bar = "█" * filled + "░" * (bar_width - filled)

    pct = frac * 100

    # ETA
    if iteration > 0 and frac > 0:
        eta_seconds = (elapsed / iteration) * (total - iteration)
    else:
        eta_seconds = -1
    eta_str = _format_time(eta_seconds)
    elapsed_str = _format_time(elapsed)

    line = (
        f"\r\033[K{label} [{bar}] {pct:5.1f}% "
        f"{iteration}/{total} "
        f"| loss: {current_loss:.6f}  best: {best_loss:.6f} "
        f"| ⏱ {elapsed_str}  ETA: {eta_str}"
    )
    return line


def _write_progress(line: str) -> None:
    """Escribe la barra de progreso a stdout con flush explícito (compatible Colab)."""
    sys.stdout.write(line)
    sys.stdout.flush()


class _ProgressTracker:
    """
    Rastrea el progreso global del fine-tuning a nivel de evaluación individual.
    Compartido entre la función objetivo wrappeada y los callbacks del optimizador.
    """
    __slots__ = (
        "start_time", "total_evals", "eval_count", "best_loss",
        "current_loss", "label", "verbose", "last_print_time",
    )

    def __init__(
        self,
        total_evals: int,
        label: str = "",
        verbose: bool = True,
    ) -> None:
        self.start_time = time.time()
        self.total_evals = total_evals
        self.eval_count = 0
        self.best_loss = float("inf")
        self.current_loss = float("inf")
        self.label = label
        self.verbose = verbose
        self.last_print_time = 0.0  # throttle prints to at most every 0.5s

    def register_eval(self, loss: float) -> None:
        """Llamado desde dentro de la función objetivo en cada evaluación."""
        self.eval_count += 1
        self.current_loss = loss
        if loss < self.best_loss:
            self.best_loss = loss
        if self.verbose:
            now = time.time()
            # Throttle: no imprimir más de 2 veces por segundo (evita flicker)
            if now - self.last_print_time > 0.5 or self.eval_count >= self.total_evals:
                self._print()
                self.last_print_time = now

    def register_iteration(self, count: int) -> None:
        """Llamado desde el callback de DE para notificar fin de generación."""
        # Forzar print al terminar cada generación
        if self.verbose:
            self._print()

    def _print(self) -> None:
        elapsed = time.time() - self.start_time
        line = _render_progress(
            iteration=self.eval_count,
            total=self.total_evals,
            best_loss=self.best_loss,
            current_loss=self.current_loss,
            elapsed=elapsed,
            label=self.label,
        )
        _write_progress(line)

    def finish(self) -> None:
        """Cierra la línea de progreso."""
        if self.verbose:
            sys.stdout.write("\n")
            sys.stdout.flush()


# ============================================================================
# Algoritmos de optimización
# ============================================================================

def _optimize_de(
    objective: Callable[[np.ndarray], float],
    bounds: List[Tuple[float, float]],
    cfg: OptimizerConfig,
    tracker: _ProgressTracker,
    history: List,
) -> Dict[str, Any]:
    """
    Differential Evolution (scipy).

    El progreso se imprime desde la función objetivo wrappeada
    (tracker.register_eval). El callback solo registra fin de generación
    sin re-evaluar la función objetivo.
    """
    try:
        from scipy.optimize import differential_evolution
    except ImportError:
        if tracker.verbose:
            print("[WARN] scipy no disponible. Usando random search.")
        return _optimize_random(objective, bounds, cfg, tracker, history)

    gen_count = [0]  # mutable para usar en callback

    def callback(xk: np.ndarray, convergence: float = 0.0) -> bool:
        gen_count[0] += 1
        history.append((len(history), tracker.best_loss))
        tracker.register_iteration(gen_count[0])
        return False  # continuar

    if tracker.verbose:
        print(f"[DE] Iniciando differential_evolution (maxiter={cfg.max_iterations}, "
              f"popsize={cfg.population_size}, ~{tracker.total_evals} evaluaciones)...")

    result = differential_evolution(
        objective,
        bounds=bounds,
        seed=cfg.seed,
        maxiter=cfg.max_iterations,
        popsize=cfg.population_size,
        tol=cfg.de_tol,
        polish=cfg.de_polish,
        mutation=cfg.de_mutation,
        recombination=cfg.de_recombination,
        workers=1,
        updating="immediate",
        callback=callback,
    )

    best_x = result.x
    best_loss = min(result.fun, tracker.best_loss)

    return {"x": best_x, "fun": best_loss}


def _optimize_random(
    objective: Callable[[np.ndarray], float],
    bounds: List[Tuple[float, float]],
    cfg: OptimizerConfig,
    tracker: _ProgressTracker,
    history: List,
    x0: Optional[np.ndarray] = None,
) -> Dict[str, Any]:
    """
    Búsqueda aleatoria con warm-start desde defaults.

    70% de las muestras: perturbación local (±20%) alrededor de x0.
    30% de las muestras: exploración uniforme global.
    Siempre evalúa x0 primero.
    """
    rng = np.random.default_rng(cfg.seed)
    best_loss = float("inf")
    best_x: Optional[np.ndarray] = None

    n = cfg.random_samples
    if tracker.verbose:
        print(f"[RandomSearch] {n} muestras (70% local + 30% global)...")

    # Siempre evaluar el punto default primero
    if x0 is not None:
        loss = float(objective(x0))
        history.append((0, loss))
        best_loss = loss
        best_x = x0.copy()
        if tracker.verbose:
            _write_progress(_render_progress(
                iteration=1, total=n, best_loss=best_loss, current_loss=loss,
                elapsed=time.time() - tracker.start_time, label="[RandomSearch]",
            ))

    for i in range(n):
        ith = len(history)
        if x0 is not None and rng.random() < cfg.random_local_ratio:
            x = np.zeros(len(bounds), dtype=float)
            for j, (lo, hi) in enumerate(bounds):
                sigma = cfg.random_local_sigma * (hi - lo)
                val = rng.normal(x0[j], sigma)
                x[j] = float(np.clip(val, lo, hi))
        else:
            x = np.array([rng.uniform(lo, hi) for lo, hi in bounds], dtype=float)

        loss = float(objective(x))
        history.append((ith, loss))

        if loss < best_loss:
            best_loss = loss
            best_x = x.copy()

        # Early stopping
        patience = cfg.early_stopping_patience
        if ith >= patience:
            recent = [h[1] for h in history[-patience:]]
            if min(recent) >= best_loss - cfg.early_stopping_min_delta:
                if tracker.verbose:
                    _write_progress(f"\n[RandomSearch] Early stopping en iteración {ith + 1}\n")
                break

    if best_x is None:
        best_x = np.array([(lo + hi) / 2 for lo, hi in bounds])

    return {"x": best_x, "fun": best_loss}


def _optimize_lbfgsb(
    objective: Callable[[np.ndarray], float],
    bounds: List[Tuple[float, float]],
    cfg: OptimizerConfig,
    tracker: _ProgressTracker,
    history: List,
) -> Dict[str, Any]:
    """L-BFGS-B (scipy). Típicamente usado como refinamiento post-DE."""
    try:
        from scipy.optimize import minimize
    except ImportError:
        return _optimize_random(objective, bounds, cfg, tracker, history)

    x0 = np.array([(lo + hi) / 2 for lo, hi in bounds])

    def callback(xk: np.ndarray) -> None:
        history.append((len(history), tracker.best_loss))

    if tracker.verbose:
        print(f"[L-BFGS-B] Iniciando (maxiter={cfg.lbfgsb_maxiter})...")

    result = minimize(
        objective,
        x0,
        method="L-BFGS-B",
        bounds=bounds,
        options={"maxiter": cfg.lbfgsb_maxiter},
        callback=callback,
    )

    return {"x": result.x, "fun": min(result.fun, tracker.best_loss)}


def _optimize_optuna(
    objective: Callable[[np.ndarray], float],
    bounds: List[Tuple[float, float]],
    cfg: OptimizerConfig,
    tracker: _ProgressTracker,
    history: List,
) -> Dict[str, Any]:
    """Optuna (opcional, requiere pip install optuna)."""
    try:
        import optuna
    except ImportError:
        if tracker.verbose:
            print("[WARN] optuna no instalado. Usando random search.")
        return _optimize_random(objective, bounds, cfg, tracker, history)

    def optuna_objective(trial: optuna.Trial) -> float:
        x = np.array([
            trial.suggest_float(f"x{i}", lo, hi)
            for i, (lo, hi) in enumerate(bounds)
        ])
        loss = float(objective(x))
        history.append((len(history), loss))
        return loss

    sampler_map = {
        "TPE": optuna.samplers.TPESampler(seed=cfg.seed),
        "Random": optuna.samplers.RandomSampler(seed=cfg.seed),
        "CMA-ES": optuna.samplers.CmaEsSampler(seed=cfg.seed),
    }
    sampler = sampler_map.get(cfg.optuna_sampler, sampler_map["TPE"])

    study = optuna.create_study(direction="minimize", sampler=sampler)

    if tracker.verbose:
        print(f"[Optuna] {cfg.optuna_n_trials} trials con sampler={cfg.optuna_sampler}...")

    study.optimize(
        optuna_objective,
        n_trials=cfg.optuna_n_trials,
        show_progress_bar=False,
    )

    best_x = np.array([study.best_params[f"x{i}"] for i in range(len(bounds))])
    best_loss = min(study.best_value or float("inf"), tracker.best_loss)

    return {"x": best_x, "fun": best_loss}


# ============================================================================
# Diagnóstico y reporting
# ============================================================================

def _compute_diagnostics(
    model: PenalizacionCargaHistoricaModel,
    scenarios: pd.DataFrame,
) -> Dict[str, Any]:
    """Calcula métricas de diagnóstico post-fine-tuning."""
    if len(scenarios) == 0:
        return {}

    abs_pen = np.abs(scenarios["penalty_predicho"].to_numpy(dtype=float))

    # Estadísticas de escala
    median = float(np.median(abs_pen))
    q25, q75 = float(np.quantile(abs_pen, 0.25)), float(np.quantile(abs_pen, 0.75))
    iqr = q75 - q25
    mean_abs = float(np.mean(abs_pen))

    # Monotonicidad por eco
    ecos = scenarios["eco"].to_numpy()
    ws = scenarios["W"].to_numpy(dtype=float)
    mono_violations = 0
    mono_total = 0
    for eco in np.unique(ecos):
        mask = ecos == eco
        w_eco = ws[mask]
        p_eco = abs_pen[mask]
        if len(w_eco) < 2:
            continue
        order = np.argsort(w_eco)
        p_sorted = p_eco[order]
        w_sorted = w_eco[order]
        for i in range(len(p_sorted) - 1):
            if w_sorted[i] == w_sorted[i + 1]:
                continue
            mono_total += 1
            if p_sorted[i] > p_sorted[i + 1] + 0.01:
                mono_violations += 1

    mono_ratio = mono_violations / max(mono_total, 1)

    # Cobertura (entropía)
    hist, _ = np.histogram(abs_pen, bins=20, range=(0, max(abs_pen.max(), 0.01)))
    hist = hist.astype(float)
    hist = hist / hist.sum()
    ent = -np.sum(hist[hist > 0] * np.log(hist[hist > 0]))
    max_ent = math.log(20)
    coverage_entropy = ent / max_ent if max_ent > 0 else 0.0

    # Diversidad entre ecos (CV acotado)
    eco_medians = scenarios.groupby("eco")["penalty_predicho"].median()
    eco_abs = eco_medians.abs()
    eco_cv = float(eco_abs.std() / max(eco_abs.mean(), 0.01)) if len(eco_abs) > 1 else 0.0
    eco_cv = min(eco_cv, 10.0)  # cap razonable

    return {
        "penalty_median": median,
        "penalty_iqr": iqr,
        "penalty_mean_abs": mean_abs,
        "monotonicity_ratio": 1.0 - mono_ratio,
        "coverage_entropy": coverage_entropy,
        "eco_cv": eco_cv,
        "n_ecos_evaluated": int(scenarios["eco"].nunique()),
        "n_scenarios": len(scenarios),
    }


def _print_summary(
    best_params: Dict[str, Any],
    loss_dict: Dict[str, float],
    metrics: Dict[str, Any],
    algorithm: str,
    elapsed: float,
) -> None:
    """Imprime resumen de fine-tuning."""
    print(f"\n{'='*60}")
    print(f"  Fine-Tuning Completado ({algorithm}) - {elapsed:.1f}s")
    print(f"{'='*60}")
    print(f"  Loss total:            {loss_dict['loss_total']:.6f}")
    print(f"    └─ Calibración:      {loss_dict.get('loss_calibration', 0):.6f}")
    print(f"    └─ Monotonicidad:    {loss_dict.get('loss_monotonicity', 0):.6f}")
    print(f"    └─ Cobertura:        {loss_dict.get('loss_coverage', 0):.6f}")
    print(f"    └─ Suavidad:         {loss_dict.get('loss_smoothness', 0):.6f}")
    print(f"    └─ Regularización:   {loss_dict.get('loss_regularization', 0):.6f}")
    print(f"    └─ Escala:           {loss_dict.get('loss_penalty_scale', 0):.6f}")
    print(f"  ──────────────────────")
    print(f"  Métricas de diagnóstico:")
    print(f"    Penalty mediana:     {metrics.get('penalty_median', 0):.4f}")
    print(f"    Penalty IQR:         {metrics.get('penalty_iqr', 0):.4f}")
    print(f"    Monotonicidad:       {metrics.get('monotonicity_ratio', 0):.2%}")
    print(f"    Cobertura (entropía): {metrics.get('coverage_entropy', 0):.3f}")
    print(f"    Diversidad eco CV:   {metrics.get('eco_cv', 0):.3f}")
    print(f"    Ecos evaluados:      {metrics.get('n_ecos_evaluated', 0)}")
    print(f"    Escenarios:          {metrics.get('n_scenarios', 0)}")
    print(f"  ──────────────────────")
    print(f"  Parámetros principales:")
    for k, v in sorted(best_params.items()):
        if isinstance(v, (list, tuple)):
            print(f"    {k}: {v}")
        else:
            print(f"    {k}: {v:.4f}")
    print(f"{'='*60}\n")
